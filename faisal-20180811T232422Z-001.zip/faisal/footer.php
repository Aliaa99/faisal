<footer>
<div class="footer pt-4">
    <div class="container">
        <div class="first-row py-1 px-3">
            <div class="row">
                <div class="col-sm-5">
                    <img src="images/8.png" alt="">
                </div>
                <div class="col-sm-7 ">
                    <div class="pt-4">
                        <a href="#" class=""><i class="fab fa-google-plus-g"></i></a>
                        <a href="#" class=""><i class="fab fa-instagram"></i></a>
                        <a href="#" class=""><i class="fab fa-twitter"></i></a>
                        <a href="#" class=""><i class="fab fa-facebook-f"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="second-row my-5 text-right">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <h4 class="py-4">روابط مهمه</h4>
                    <ul class="first-list">
                        <li><a href="#">الرئيسية</a></li>
                        <li><a href="#">راسلنا</a></li>
                        <li><a href="#">من نحن</a></li>
                        <li><a href="#">أهدافنا</a></li>
                        <li><a href="#">أعمالنا</a></li>
                        <li><a href="#">تواصل معنا</a></li>
                        <li><a href="#">الشهادات</a></li>
                    </ul>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <h4 class="py-4">موقعنا على الخريطة</h4>
                    <div class="map">
                       <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d13675.310969623733!2d31.368624730224607!3d31.031048599999988!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sar!2seg!4v1531923822749" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <h4 class="py-4">تواصل معنا </h4>
                    <ul>
                        <li class="li-icons1"><a href="#">السعودية/الرياض</a></li>
                        <li class="li-icons2"><a href="#">+96475144521</a></li>
                        <li class="li-icons3"><a href="#">447875656524</a></li>
                        <li class="li-icons4"><a href="#">aliaa@bb4it.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="by-us pt-3">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 text-right">
                    <p>جميع الحقوق محفوظة2018</p>
                </div>
                <div class="col-sm-6">
                    <p>تصميم وبرمجة<span><a href="#"> : بريمكس</a></span></p>
                </div>
            </div>
        </div>
    </div>
</div>
</foote>

<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap4.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/lightbox.js"></script>
<script src="js/aos.js"></script>
<script>
  AOS.init();
</script>
<script src="js/main.js"></script>
</body>
</html>