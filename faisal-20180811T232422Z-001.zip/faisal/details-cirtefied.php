<?php
include 'header.php';
?>


<div class="main-header text-center py-5 my-2">
    <div class="container">
        <h1>الشهادات الموثقة</h1>
        <a href="index.php">الرئيسية</a>
    </div>
</div>


<div class="certificate mt-2 py-5" >
    <div class="container">
        <div class="head-div2 text-center mb-5">
            <h1>الشهادات المرفقه </h1>
            <div class="image-after">
                <span><img src="images/2.png" alt=""></span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4  col-sm-6 " data-aos="zoom-in" >
                <div class="shahada mb-3">
                    <a  data-fancybox="gallery" href="images/3.png" class="various fancyboxvarious fancybox">
                        <img src="images/3.png" alt="">
                    </a>
                    <h3 class="px-3 py-3">شهادة تصنيف المقاولين</h3>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 " data-aos="zoom-in" >
                <div class="shahada mb-3">
                    <a data-fancybox="gallery" href="images/3.png" class="various fancyboxvarious fancybox">
                        <img src="images/3.png" alt="">
                    </a>
                    <h3 class="px-3 py-3">شهادة تصنيف المقاولين</h3>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 " data-aos="zoom-in" >
                <div class="shahada mb-3">
                    <a  data-fancybox="gallery" href="images/3.png" class="various fancyboxvarious fancybox">
                        <img src="images/3.png" alt="">
                    </a>
                    <h3 class="px-3 py-3">شهادة تصنيف المقاولين</h3>
                </div>
            </div>

        </div>
    </div>
</div>


<?php
include 'with-us-part.php';
?>




<?php
include 'footer.php';
?>
