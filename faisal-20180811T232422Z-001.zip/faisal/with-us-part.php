<div class="with-us py-5" data-aos="zoom-in-down">
    <div class="container">
        <div class="head-div2 text-center">
            <h1>شركائنا </h1>
            <div class="image-after">
                <span><img src="images/2.png" alt=""></span>
            </div>
        </div>
        <div class="owl-carousel owl-theme my-5">
            <div class="item hvr-skew">
                <img src="images/4.png" alt="">
            </div>
        </div>
    </div>
</div>
