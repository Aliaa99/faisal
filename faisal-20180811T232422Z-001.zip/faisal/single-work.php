<?php
include 'header.php';
?>


<div class="main-header text-center py-5 my-2">
    <div class="container">
        <h1>مشروع طريق الملك سلمان</h1>
        <a href="index.php">الرئيسية</a><a href="index.php">/أعمالنا</a>
    </div>
</div>


<div class="about text-right" data-aos="flip-left">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <img src="images/1.png" alt="">
            </div>
            <div class="col-md-8 col-sm-12">
                <div class="about-details pr-4">
                    <p class="mb-4">يسرنا أن نطلع القارئ فيما يلي ومن خالل كلمات قليلة ومقتضبة على أبرز ما نميز شركتنا من نجاحـــات وإنجازات امتـدد أكثر من 10 أعوام, كانــت حافلة بالتفــوق والتميز بفضل عملنا الجاد وحرصنا على أن نولي عمالءنا الكرام اآلولوية الفصــوى التي يستحقـــونها. 
                    استهلت الشركة أعمالها عام 2006 من خالل تاسيس مؤسسه الفيصل الول للمقاوالت وذلك للعمل على خدمات نقل وتوزيع الطاقة الكهربائية لجهات القطاع الخاص والمشروعات المدنية القائمة على نظام تسليم المفتاح. ومنذ انط ـالقنا وحتى اليــوم تغفخـر شركتنا بتمتعها برأس مال سعودي تبلغ نسبته 100%. 1 تمحورت رؤيتنا منذ البداية على تبوأ مكانة رائدة وسباقة في مجال أعمال المقاوالت الكهربائية على مستوى المملكــة العربية السعودية. ومن ثمــة تبلورت رسالتنا في تحقيق هذا الهدف من خالل التزامنا بأعلى معايير الجودة. ورعايتنا قيد عاملة متميزة تشاركنا هذه الرؤية الفريدة. 
                    هذا ويشهد كافة عمللؤنا الكرام شركة الكهرباء السعودية وغيرهم من الشركات المحليه على وفائنا بكافة وعودنا وتعهدائنا من حيث كفاءة وجودة األعمال المنفذة.
                    يرجع الفضل في ذلك إلى تمتعنا بايج عاملة تم اختيارها بعناية فائقة وتدريبها بدقة متناهية ورعايتها بإخالص من قبل إدارة رشيدة لبتسنى لها تقديم أفضل ما لديها مع كل مشروع يتم تنفيذه ...
                    </p>
                    <div class="social">
                        <span class="ml-3">15/4/2018</span>
                        <a href="#" class="mx-2 hvr-float"><i class="fab fa-google-plus-g"></i></a>
                        <a href="#" class="mx-2 hvr-float"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="mx-2 hvr-float"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="mx-2 hvr-float"><i class="fab fa-facebook-f"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





<div class="our-works pt-5 mt-2 pb-1">
    <div class="container">
        <div class="head-div2 text-center">
            <h1>أعمال أخرى </h1>
            <div class="image-after">
                <span><img src="images/2.png" alt=""></span>
            </div>
        </div>
        <div class="owl-carousel owl-theme my-5"   data-aos="fade-up">
            <div class="item hvr-bob">
                <img src="images/caro2.png" alt="">
                <div class="details">
                    <p>مشروع طريق الملك سلمان بمدينه حائل التابع للشركة السعودية للكهرباء تحويل الشبكه ...</p>
                    <a href="#">قراءة المزيد</a>
                </div>
            </div>
        </div>
    </div>
</div>




<?php
include 'with-us-part.php';
?>




<?php
include 'footer.php';
?>
