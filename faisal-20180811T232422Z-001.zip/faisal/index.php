<?php
include 'header.php';
?>

<div class="main-carousle">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/min-carousle.png" alt="">
            <div class="caption text-center">
                <div class="container">
                    <h1 class="animated rotateIn">مؤسسة الفصل الأول للمقاولات</h1>
                    <p class="my-5 animated zoomIn px-5">يسرنا أن نطلع القارئ فيما يلي ومن خالل كلمات قليلة ومقتضبة على أبرز ما نميز شركتنا من نجاحـــات وإنجازات امتـدد أكثر من 10 أعوام, كانــت حافلة بالتفــوق والتميز بفضل عملنا الجاد وحرصنا على أن نولي عمالءنا الكرام اآلولوية الفصــوى التي يستحقـــونها. 
                    استهلت الشركة أعمالها عام 2006 من خالل تاسيس مؤسسه الفيصل الول للمقاوالت وذلك للعمل على خدمات نقل وتوزيع الطاقة الكهربائية لجهات القطاع الخاص والمشروعات المدنية القائمة على نظام تسليم المفتاح. ومنذ انط ـالقنا وحتى اليــوم تغفخـر شركتنا بتمتعها برأس مال سعودي تبلغ نسبته 100%. 1 تمحورت رؤيتنا منذ البداية على تبوأ مكانة رائدة وسباقة في مجال أعمال المقاوالت الكهربائية على مستوى المملكــة العربية السعودية. ومن ثمــة تبلورت رسالتنا في تحقيق هذا الهدف من خالل التزامنا بأعلى معايير الجودة. ورعايتنا قيد عاملة متميزة تشاركنا هذه الرؤية الفريدة. 
                    هذا ويشهد كافة عمللؤنا الكرام شركة الكهرباء السعودية وغيرهم من الشركات المحليه على وفائنا بكافة وعودنا وتعهدائنا من حيث كفاءة وجودة األعمال المنفذة.
                    يرجع الفضل في ذلك إلى تمتعنا بايج عاملة تم اختيارها بعناية فائقة وتدريبها بدقة متناهية ورعايتها بإخالص من قبل إدارة رشيدة لبتسنى لها تقديم أفضل ما لديها مع كل مشروع يتم تنفيذه ...
                    </p>
                    <a href="about.php animated bounceInLeft" class="animated bounceInLeft ">من نحن</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'about-part.php';
?>

<div class="our-works pt-5 mt-2 pb-1">
    <div class="container">
        <div class="head-div2 text-center">
            <h1>أعمالنا </h1>
            <div class="image-after">
                <span><img src="images/2.png" alt=""></span>
            </div>
        </div>
        <div class="owl-carousel owl-theme my-5"   data-aos="fade-up">
            <div class="item hvr-bob">
                <img src="images/caro2.png" alt="">
                <div class="details">
                    <p>مشروع طريق الملك سلمان بمدينه حائل التابع للشركة السعودية للكهرباء تحويل الشبكه ...</p>
                    <a href="#">قراءة المزيد</a>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="certificate mt-2 py-5" >
    <div class="container">
        <div class="head-div2 text-center mb-5">
            <h1>الشهادات المرفقه </h1>
            <div class="image-after">
                <span><img src="images/2.png" alt=""></span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4  col-sm-6 " data-aos="zoom-in" >
                <div class="shahada mb-3">
                    <a href="#" >
                        <img src="images/3.png" alt="">
                        <h3 class="px-3 py-3">شهادة تصنيف المقاولين</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 " data-aos="zoom-in" >
                <div class="shahada mb-3">
                    <a href="#" >
                        <img src="images/3.png" alt="">
                        <h3 class="px-3 py-3">شهادة تصنيف المقاولين</h3>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 " data-aos="zoom-in" >
                <div class="shahada mb-3">
                    <a href="#" >
                        <img src="images/3.png" alt="">
                        <h3 class="px-3 py-3">شهادة تصنيف المقاولين</h3>
                    </a>
                </div>
            </div>

        </div>
        <div class="links text-center my-5">
            <a href="details-cirtefied.php" class="link1 hvr-sink px-2"> جميع الشهادات</a>
        </div>
    </div>
</div>


<?php
include 'with-us-part.php';
?>




<?php
include 'footer.php';
?>
