<?php
include 'header.php';
?>

<div class="main-header text-center py-5 my-2">
    <div class="container">
        <h1>عن المؤسسة</h1>
        <a href="index.php">الرئيسية</a>
    </div>
</div>

<?php
include 'about-part.php';
?>


<?php
include 'with-us-part.php';
?>
 

<?php
include 'footer.php';
?>