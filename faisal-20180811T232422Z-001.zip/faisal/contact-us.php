<?php
include 'header.php';
?>


<div class="main-header text-center py-5 my-2">
    <div class="container">
        <h1>تواصل معنا</h1>
        <a href="index.php">الرئيسية</a>
    </div>
</div>

<div class="contact-us my-5 py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6">
                <img src="images/1.png" alt="">
            </div>
            <div class="col-lg-8 col-md-6 col-sm-12">
                <form action="">
                    <h5>إرسال رسالة</h5>
                    <div class="form-feild">
                        <input type="text" placeholder="الاسم">
                    </div>
                    <div class="form-feild">
                        <input type="email" placeholder="الايميل">
                    </div>
                    <div class="form-feild">
                        <textarea name="" id=""  rows="6" placeholder="الرسالة"></textarea>
                    </div>
                    <div class="form-feild">
                        <button class="py-2 px-5 hvr-float">ارسال الان</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<?php
include 'with-us-part.php';
?>


<?php
include 'footer.php';
?>
