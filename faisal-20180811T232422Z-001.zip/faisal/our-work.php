<?php
include 'header.php';
?>

<div class="main-header text-center py-5 my-2">
    <div class="container">
        <h1>أعمالنا</h1>
        <a href="index.php">الرئيسية</a>
    </div>
</div>


<div class="our-works py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="item hvr-bob">
                    <img src="images/caro2.png" alt="">
                    <div class="details">
                        <p>مشروع طريق الملك سلمان بمدينه حائل التابع للشركة السعودية للكهرباء تحويل الشبكه ...</p>
                        <a href="single-work.php">قراءة المزيد</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="item hvr-bob">
                    <img src="images/caro2.png" alt="">
                    <div class="details">
                        <p>مشروع طريق الملك سلمان بمدينه حائل التابع للشركة السعودية للكهرباء تحويل الشبكه ...</p>
                        <a href="single-work.php">قراءة المزيد</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>






<?php
include 'with-us-part.php';
?>
 

<?php
include 'footer.php';
?>